package parseurs.g11;
/*
S→feS
S→BCD
B→bB ∣ ϵ
C→cC ∣ ϵ
D→dD ∣ ϵ
 */

public class ParseurG1 {
	private TokenManager tm;
	private char tc; // Token courant

	// Avancer au prochain token
	private void avancer() {
		tc = tm.suivant();
	}

	// Consommer un token spécifique
	private void consommer(char attendu) {
		if (tc == attendu) {
			avancer();
		} else
			throw new RuntimeException("Erreur: attendu '" + attendu + "' mais trouvé '" + tc + "'");
	}

	// Constructeur
	public ParseurG1(TokenManager tm) {
		this.tm = tm;
		avancer();
	}

	// Point d'entrée pour analyser la chaîne
	public void parse() {
		S();
		if (tc != '#')
			throw new RuntimeException("Erreur: caractère inattendu '" + tc + "'");

	}

	private void S() {
		if (tc == 'f') {
			consommer('f');
			consommer('e');
			S();
		} else {
			B();
			C();
			D();
		}
	}

	private void D() {
		if (tc == 'd') {
			avancer();
			D();
		}
	}

	private void C() {
		if (tc == 'c') {
			avancer();
			C();
		}
	}

	private void B() {
		if (tc == 'b') {
			avancer();
			B();
		}
	}


}
