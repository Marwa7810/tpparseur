package parseurs.g11;


import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.Test;


class ParseurTest {
	@Test
	void testEmptyString() {
		TokenManager tm = new TokenManager("");
		ParseurG1 parseur = new ParseurG1(tm);
		assertDoesNotThrow(parseur::parse, "La chaîne vide doit être valide.");
	}

	@Test
	void testFe() {
		TokenManager tm = new TokenManager("fe");
		ParseurG1 parseur = new ParseurG1(tm);
		assertDoesNotThrow(parseur::parse, "La chaîne 'fe' doit être valide.");
	}

	@Test
	void testFefefe() {
		TokenManager tm = new TokenManager("fefefe");
		ParseurG1 parseur = new ParseurG1(tm);
		assertDoesNotThrow(parseur::parse, "La chaîne 'fefefe' doit être valide.");
	}

	@Test
	void testBbb() {
		TokenManager tm = new TokenManager("bbb");
		ParseurG1 parseur = new ParseurG1(tm);
		assertDoesNotThrow(parseur::parse, "La chaîne 'bbb' doit être valide.");
	}

	@Test
	void testCcc() {
		TokenManager tm = new TokenManager("ccc");
		ParseurG1 parseur = new ParseurG1(tm);
		assertDoesNotThrow(parseur::parse, "La chaîne 'ccc' doit être valide.");
	}

	@Test
	void testDdd() {
		TokenManager tm = new TokenManager("ddd");
		ParseurG1 parseur = new ParseurG1(tm);
		assertDoesNotThrow(parseur::parse, "La chaîne 'ddd' doit être valide.");
	}

	@Test
	void testBcd() {
		TokenManager tm = new TokenManager("bcd");
		ParseurG1 parseur = new ParseurG1(tm);
		assertDoesNotThrow(parseur::parse, "La chaîne 'bcd' doit être valide.");
	}

	@Test
	void testFed() {
		TokenManager tm = new TokenManager("fed");
		ParseurG1 parseur = new ParseurG1(tm);
		assertDoesNotThrow(parseur::parse, "La chaîne 'fed' doit être valide.");
	}

	@Test
	void testFecd() {
		TokenManager tm = new TokenManager("fecd");
		ParseurG1 parseur = new ParseurG1(tm);
		assertDoesNotThrow(parseur::parse, "La chaîne 'fecd' doit être valide.");
	}

	// Chaînes non valides
	@Test
	void testInvalidCb() {
		TokenManager tm = new TokenManager("cb");
		ParseurG1 parseur = new ParseurG1(tm);
		assertThrows(RuntimeException.class, parseur::parse, "La chaîne 'cb' est invalide.");
	}

	@Test
	void testInvalidDc() {
		TokenManager tm = new TokenManager("dc");
		ParseurG1 parseur = new ParseurG1(tm);
		assertThrows(RuntimeException.class, parseur::parse, "La chaîne 'dc' est invalide.");
	}

	@Test
	void testInvalidDb() {
		TokenManager tm = new TokenManager("db");
		ParseurG1 parseur = new ParseurG1(tm);
		assertThrows(RuntimeException.class, parseur::parse, "La chaîne 'db' est invalide.");
	}

	@Test
	void testInvalidFebcdfe() {
		TokenManager tm = new TokenManager("febcdfe");
		ParseurG1 parseur = new ParseurG1(tm);
		assertThrows(RuntimeException.class, parseur::parse, "La chaîne 'febcdfe' est invalide.");
	}

}
